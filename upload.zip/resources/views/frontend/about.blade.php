{%  extends 'base.html' %}
{%  load static  %}



{%  block body  %}

<style>
    .render::after{
        content: "";
        position: absolute;
        top: 85%;
        background-color:#6DAD26;
        width: 40px;
        height: 3px;
        left:49.4%;
    }

    .render::before{
        content: "";
        position: absolute;
        top: 85%;
        background-color:#8bc8a6;
        width: 80px;
        height: 3px;
        left:48%;
    }
    .solar{
        background-image: url('../static/assets/images/solar/install.jpg');
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        height: 50vh;
        background-blend-mode: hard-light;
        background-color: rgba(0, 0, 0, 0.56);
    }
</style>

        <main class="main">
            <div class="page-header text-center" style="background-image: url('assets/images/page-header-bg.jpg')">
        		<div class="container">
        			<h1 class="page-title">About us<span></span></h1>
        		</div><!-- End .container -->
        	</div><!-- End .page-header -->
            <nav aria-label="breadcrumb" class="breadcrumb-nav">
                <div class="container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{%  url 'index:home' %}">Home</a></li>
                        <!-- <li class="breadcrumb-item"><a href="#">Pages</a></li> -->
                        <li class="breadcrumb-item active" aria-current="page">About us </li>
                    </ol>
                </div><!-- End .container -->
            </nav><!-- End .breadcrumb-nav -->
            <section >
                <div class="pb-3  mb-lg-8">
                    <div class="container">
                        <div class="row ">
                            {% for i in about %}
                            <div class="col-lg-6 col-12 col-sm-12 mb-3 mb-lg-0">
                                <h2 class="title">{{  i.heading }}</h2><!-- End .title -->
                                <p class="lead text-primary mb-3" style="line-height:50px;">
                                    {{ i.body|safe }}
                                </p>

                                <a href="{% url 'index:blog'  %}" class="btn btn-sm btn-minwidth btn-outline-primary-2 mt-3">
                                    <span>VIEW OUR NEWS</span>
                                    <i class="icon-long-arrow-right"></i>
                                </a>
                            </div><!-- End .col-lg-5 -->

                            <div class="col-lg-6 col-12 col-sm-12 pb-5 offset-lg-0">
                                <div class="about-images">
                                    <!-- <img src="{% static 'assets/images/solar/about (2).jpg' %}" alt="" class="about-img-front img-fluid"> -->
                                    <img src="{{  i.image.url }}" alt="" class=" img-fluid">-
                                </div><!-- End .about-images -->
                            </div><!-- End .col-lg-6 -->
                            {%  endfor %}
                        </div><!-- End .row -->
                    </div><!-- End .container -->
                </div><!-- End .bg-light-2 pt-6 pb-6 -->
            </section><!-- End section -->

            <section class="">
                <div class="container">
                    <div class="row ">
                        <div class="col-12 col-lg-12">
                            <h3 class="text-center render">Services we Render</h3>
                        </div>
                    </div>
                    <div class="row pt-5 align-items-center">
                        <div class="col-lg-5 offset-lg-0">
                            <div class="bg-primary p-5">
                                <h2>Installations of Solar</h2>
                                <p>Our professional IT management means you don't have <br> to worry about your business computer network.</p>
                            </div>
                            
                        </div>
                        <div class="col-lg-6">
                            <!-- <img src="/static/assets/images/solaar.jpg" class="img-fluid" alt=""> -->
                            <div class="solar"></div>
                        </div>
                    </div>
                    <div class="row  align-items-center">    
                        <div class="col-lg-5 offset-lg-0 order-sm-first order-md-first order-lg-last">
                            <div class="bg-primary p-5 text-white">
                                <h2 style="font-size:25px;font-weight:600;">
                                    sales outlets & Edo job boxes distributed (100 boxes) Beta life box,
                                </h2>
                                <p>
                                    Our professional IT management means you don't have 
                                    <br> to worry about your business computer network.
                                </p>
                            </div>
                            
                        </div>
                        <div class="col-lg-6">
                            <div class="solar"></div>
                        </div>
                    </div>
                    <div class="row  align-items-center">    
                        <div class="col-lg-5 offset-lg-0">
                            <div class="bg-primary p-5 text-white">
                                <h2>training</h2>
                                <p>
                                    Our professional IT management means you don't have 
                                    <br> to worry about your business computer network.
                                </p>
                            </div>
                            
                        </div>
                        <div class="col-lg-6 order-sm-first order-sm-last order-lg-last">
                            <div class="solar"></div>
                        </div>

                    </div>
                    <div class="row pb-5 align-items-center">
                        <div class="col-lg-5 offset-lg-0  order-sm-first order-md-first order-lg-last">
                            <div class="bg-primary p-5 text-white">
                                <h2>CCTV cameras & electric fencing.</h2> 
                                <p>
                                    Our professional IT management means you don't have 
                                    to worry about your business computer network.
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="solar"></div>
                        </div>
                    </div>
                </div>
            </section>
        </main><!-- End .main -->

{%  endblock body  %}    