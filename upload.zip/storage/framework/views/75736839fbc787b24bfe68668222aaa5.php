<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title></title>
    <meta name="keywords" content="solar">
    <meta name="description" content="Learn about the Energy Department&#039;s efforts to advance technologies that drive down the cost of solar energy in Nigerian.">
    <meta name="author" content="p-themes">
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/images/solar/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/images/solar/logo.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/images/solar/logo.png">
    <link rel="manifest" href="/assets/images/solar/logo.png">
    <link rel="mask-icon" href="/assets/images/solar/logo.png" color="#666666">
    <link rel="shortcut icon" href="/assets/images/solar/logo.png">
    <meta name="apple-mobile-web-app-title" content="Green Fusion">
    <meta name="application-name" content="Green Fusion">
    <meta name="msapplication-TileColor" content="#cc9966">
    <meta name="msapplication-config" content="/assets/images/solar/logo.png">
    <meta name="theme-color" content="#ffffff">

          <!-- Place favicon.ico in the root directory -->
          <link rel="shortcut icon" type="image/x-icon" href="assets/img/logo/favicon.png">

          <!-- CSS here -->
          <link rel="stylesheet" href="/assets/css/bootstrap.css">
          <link rel="stylesheet" href="/assets/css/animate.css">
          <link rel="stylesheet" href="/assets/css/swiper-bundle.css">
          <link rel="stylesheet" href="/assets/css/slick.css">
          <link rel="stylesheet" href="/assets/css/magnific-popup.css">
          <link rel="stylesheet" href="/assets/css/font-awesome-pro.css">
          <link rel="stylesheet" href="/assets/css/flaticon_shofy.css">
          <link rel="stylesheet" href="/assets/css/spacing.css">
          <link rel="stylesheet" href="/assets/css/main.css">

          <script  src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

</head>

<body>
         <!-- pre loader area start -->
         <div id="loading">
            <div id="loading-center">
               <div id="loading-center-absolute">
                  <!-- loading content here -->
                  <div class="tp-preloader-content">
                     <div class="tp-preloader-logo">
                        <div class="tp-preloader-circle">
                           
                        </div>
                        
                     </div>
                     
                     
                  </div>
               </div>
            </div>
         </div>
         <!-- pre loader area end -->

         <!-- back to top start -->
         <div class="back-to-top-wrapper">
            <button id="back_to_top" type="button" class="back-to-top-btn">
               <svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M11 6L6 1L1 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
               </svg>
            </button>
         </div>
         <!-- back to top end -->



         <!-- mobile menu area start -->
         <?php echo $__env->make('partials.mobile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- mobile menu area end -->

         <!-- search area start -->
              <?php echo $__env->make('partials.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- search area end -->

        <!-- cart mini area start -->
            <?php echo $__env->make('partials.cart-mini', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- cart mini area end -->

         <!-- header area start -->
              <?php echo $__env->yieldContent('head'); ?>
         <!-- header area end -->




        <main>
             <?php echo $__env->yieldContent('content'); ?>
        </main>

    <!-- footer area start -->
       <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- footer area end -->

 <script src="/assets/js/vendor/jquery.js"></script>
 <script src="/assets/js/vendor/waypoints.js"></script>
 <script src="/assets/js/bootstrap-bundle.js"></script>
 <script src="/assets/js/meanmenu.js"></script>
 <script src="/assets/js/swiper-bundle.js"></script>
 <script src="/assets/js/slick.js"></script>
 <script src="/assets/js/range-slider.js"></script>
 <script src="/assets/js/magnific-popup.js"></script>
 <script src="/assets/js/nice-select.js"></script>
 <script src="/assets/js/purecounter.js"></script>
 <script src="/assets/js/countdown.js"></script>
 <script src="/assets/js/wow.js"></script>
 <script src="/assets/js/isotope-pkgd.js"></script>
 <script src="/assets/js/imagesloaded-pkgd.js"></script>
 <script src="/assets/js/ajax-form.js"></script>
 <script src="/assets/js/main.js"></script>
 <script src="script.js"></script>
 <?php echo $__env->yieldContent('scripts'); ?>
 <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Single-Vendor-Ecommerce\resources\views/layouts/main.blade.php ENDPATH**/ ?>