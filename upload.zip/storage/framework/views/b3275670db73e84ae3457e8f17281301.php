<?php $__env->startSection('head'); ?>
   <?php echo $__env->make('partials.subheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<main>

    <!-- breadcrumb area start -->
    <section class="breadcrumb__area include-bg pt-95 pb-50" data-bg-color="#EFF1F5">
       <div class="container">
          <div class="row">
             <div class="col-xxl-12">
                <div class="breadcrumb__content p-relative z-index-1">
                   <h3 class="breadcrumb__title">Checkout</h3>
                   <div class="breadcrumb__list">
                      <span><a href="#">Home</a></span>
                      <span>Checkout</span>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </section>
    <!-- breadcrumb area end -->

    <!-- checkout area start -->
    <section class="tp-checkout-area pb-120" data-bg-color="#EFF1F5">
       <div class="container">
        <form action="<?php echo e(route('checkout.submit')); ?>" id="paymentForm" method="POST">
            <?php echo csrf_field(); ?>
          <div class="row">

             <div class="col-lg-7">
                <div class="tp-checkout-bill-area">
                   <h3 class="tp-checkout-bill-title">Billing Details</h3>

                   <div class="tp-checkout-bill-form">

                         <div class="tp-checkout-bill-inner">
                            <div class="row">
                               <div class="col-md-6">
                                  <div class="tp-checkout-input">
                                     <label>First Name <span>*</span></label>
                                     <input type="text" name="name" required placeholder="First Name">
                                  </div>
                               </div>

                               <div class="col-md-6">
                                  <div class="tp-checkout-input">
                                     <label>Last Name <span>*</span></label>
                                     <input type="text" name="lastname" value="<?php echo e(old('lastname')); ?>" required placeholder="Last Name">
                                  </div>
                               </div>
                               <div class="col-md-12">
                                <div class="tp-checkout-input">
                                   <label>Email address <span>*</span></label>
                                   <input type="email" name="email" id="email-address" value="<?php echo e(old('email')); ?>" required>
                                </div>
                             </div>
                               
                               
                               <div class="col-md-12">
                                  <div class="tp-checkout-input">
                                     <label>Street address</label>
                                     <input type="text" name="address" required placeholder="House number and street name">
                                  </div>

                                  
                               </div>
                               
                                <div class="col-md-6">
                                  
                               </div>
                               
                               <div class="col-md-12">
                                  <div class="tp-checkout-input">
                                     <label>Phone <span>*</span></label>
                                     <input type="tel" name="phone_number" id="phone_number" value="<?php echo e(old('phone_number')); ?>" required>
                                  </div>
                               </div>
                               <input type="hidden" name="reference" value="<?php echo e(Paystack::genTranxRef()); ?>">
                               <input type="hidden" name="currency" value="NGN">
                               
                            </div>
                         </div>

                   </div>
                </div>
             </div>
             <div class="col-lg-5">
                <!-- checkout place order -->
                <div class=" mb-3 tp-checkout-place white-bg">
                   <h3 class="tp-checkout-place-title">Your Order</h3>

                   <div class="tp-order-info-list">
                      <ul>

                         <!-- header -->
                         <li class="tp-order-info-list-header">
                            <h4>Product</h4>
                            <h4>Total</h4>
                         </li>

                         <!-- item list -->
                         <?php $__currentLoopData = $productItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="tp-order-info-list-desc">
                                <p><?php echo e($item->product->name); ?> <span> x <?php echo e($item->quantity); ?></span></p>
                                <span>$<?php echo e($item->product->price); ?></span>
                            </li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                         <!-- subtotal -->
                         <li class="tp-order-info-list-subtotal">
                            <span>Subtotal</span>
                            <span>$<?php echo e($totalprice); ?></span>
                         </li>

                         <!-- shipping -->
                         <li class="tp-order-info-list-shipping">
                            <span>Shipping</span>
                            <div class="tp-order-info-list-shipping-item d-flex flex-column align-items-end">
                               
                               <span>
                                  <input id="free_shipping" type="radio" name="shipping_fee">
                                  <label for="free_shipping">Free shipping</label>
                               </span>
                            </div>
                         </li>

                         <!-- total -->
                         <li class="tp-order-info-list-total">
                            <span>Total</span>
                            <span>$<?php echo e($total); ?></span>
                         </li>
                      </ul>
                   </div>
                   <div class="tp-checkout-agree">
                      <div class="tp-checkout-option">
                         <input id="read_all" type="checkbox">
                         <label for="read_all">I have read and agree to the website.</label>
                      </div>
                   </div>
                   <div class="tp-checkout-btn-wrapper">
                      <button type="submit" class="tp-checkout-btn w-100 text-white">Place Order</button>
                   </div>
                </div>
             </div>
          </div>
        </form>
          
       </div>
    </section>
    <!-- checkout area end -->


 </main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Single-Vendor-Ecommerce\resources\views/frontend/checkout.blade.php ENDPATH**/ ?>